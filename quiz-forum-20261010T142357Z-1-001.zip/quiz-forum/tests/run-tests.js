/* End-to-end tests: loads the real index.html in jsdom (real timers, real DOM events),
   with a fake backend that runs the real Code.gs logic.  Run:  node tests/run-tests.js */
"use strict";
const path = require("path");
const fs = require("fs");
const { execFileSync } = require("child_process");
const { JSDOM, VirtualConsole } = require("jsdom");
const http = require("http");
const { createBackend } = require("./appsscript-mock");

// tiny static server so the page loads exactly as it would when hosted
const MIME = { ".html": "text/html", ".js": "text/javascript", ".css": "text/css" };
let BASE = "";
const server = http.createServer((req, res) => {
  const p = path.join(ROOT, decodeURIComponent(req.url.split("?")[0]).replace(/^\/$/, "/index.html"));
  if (!p.startsWith(ROOT) || !fs.existsSync(p) || fs.statSync(p).isDirectory()) { res.writeHead(404); return res.end("nf"); }
  res.writeHead(200, { "Content-Type": MIME[path.extname(p)] || "application/octet-stream" });
  fs.createReadStream(p).pipe(res);
});

const ROOT = path.join(__dirname, "..");
const OUT = path.join(__dirname, "output");
fs.mkdirSync(OUT, { recursive: true });

let passed = 0, failed = 0;
const failures = [];
function check(cond, label) {
  if (cond) { passed++; console.log("  PASS  " + label); }
  else { failed++; failures.push(label); console.log("  FAIL  " + label); }
}
const sleep = (ms) => new Promise(r => setTimeout(r, ms));
async function waitFor(fn, timeout = 5000, step = 25) {
  const t0 = Date.now();
  while (Date.now() - t0 < timeout) { if (fn()) return true; await sleep(step); }
  return false;
}

/* ---------- harness ---------- */
async function boot(opts = {}) {
  const backend = opts.backend || createBackend();
  const state = { fetchMode: "ok", fetchCalls: 0, intervals: 0, maxIntervals: 0, blobs: [], perfOffset: 0, errors: [] };
  const vc = new VirtualConsole();
  vc.on("jsdomError", (e) => { if (!/getContext|Not implemented/.test(String(e.message))) state.errors.push(String(e.message)); });

  const dom = await JSDOM.fromURL(BASE + "/index.html", {
    runScripts: "dangerously", resources: "usable", pretendToBeVisual: true,
    virtualConsole: vc,
    beforeParse(win) {
      win.scrollTo = () => {};
      win.confirm = () => true;
      win.open = (u) => { state.opened = u; return {}; };
      const realSet = win.setInterval.bind(win), realClear = win.clearInterval.bind(win), live = new Set();
      win.setInterval = (fn, ms) => { const id = realSet(fn, ms); live.add(id); state.intervals = live.size; state.maxIntervals = Math.max(state.maxIntervals, live.size); return id; };
      win.clearInterval = (id) => { live.delete(id); state.intervals = live.size; return realClear(id); };
      const realNow = win.performance.now.bind(win.performance);
      Object.defineProperty(win.performance, "now", { configurable: true, value: () => realNow() + state.perfOffset });
      win.URL.createObjectURL = (b) => { state.blobs.push(b); return "blob:test/" + state.blobs.length; };
      win.URL.revokeObjectURL = () => {};
      win.HTMLAnchorElement.prototype.click = function () { state.lastDownload = { href: this.href, name: this.download }; };
      win.fetch = async (url, o) => {
        state.fetchCalls++;
        state.lastRequest = { url, o };
        if (state.fetchMode === "fail") throw new TypeError("Failed to fetch");
        if (state.fetchMode === "http500") return { ok: false, status: 500, json: async () => ({}) };
        const data = backend.post(o.body);
        if (state.fetchMode === "lost-response") { state.fetchMode = "ok"; throw new TypeError("Failed to fetch"); }
        return { ok: true, status: 200, json: async () => data };
      };
      if (opts.localStorage) for (const k in opts.localStorage) win.localStorage.setItem(k, opts.localStorage[k]);
    }
  });
  const win = dom.window, doc = win.document;
  await waitFor(() => win.__QF && win.QF_CONFIG, 5000);
  const $ = (id) => doc.getElementById(id);
  const api = {
    dom, win, doc, $, backend, state,
    cfg: win.QF_CONFIG,
    visible: (id) => !$(id).hidden,
    async start(name) {
      $("name-input").value = name;
      $("start-form").dispatchEvent(new win.Event("submit", { cancelable: true, bubbles: true }));
    },
    qText: () => $("q-statement").textContent,
    S: () => win.__QF.state(),
    answer(v) { $(v === "TRUE" ? "btn-true" : "btn-false").click(); },
    async nextQuestion(prevText) { return waitFor(() => $("q-statement").textContent !== prevText || api.visible("screen-results"), 4000); }
  };
  return api;
}

/* answer pattern for a full run (all keys are TRUE): i%5==1 -> FALSE (wrong), i%5==3 -> timeout, else TRUE */
async function playFullRun(a, pattern) {
  for (let i = 0; i < a.S().order.length; i++) {
    const text = a.qText(), kind = pattern(i);
    if (kind === "T") a.answer("TRUE");
    else if (kind === "F") a.answer("FALSE");
    else await sleep(a.cfg.timerSeconds * 1000 + 250);   // let it time out
    if (!(await waitFor(() => a.qText() !== text || a.visible("screen-results"), 4000))) throw new Error("did not advance after Q" + (i + 1));
  }
}
const pattern9 = (i) => (i % 5 === 1 ? "F" : i % 5 === 3 ? "X" : "T");   // 9 correct, 3 wrong, 3 timeout

/* ================= TESTS ================= */
(async function main() {
  await new Promise(r => server.listen(0, "127.0.0.1", r));
  BASE = "http://127.0.0.1:" + server.address().port;
  const t0 = Date.now();

  console.log("\n[1] Data integrity");
  {
    const a = await boot();
    const Q = a.win.QF_QUESTIONS;
    check(Q.length === 15, "question bank has 15 questions");
    check(new Set(Q.map(q => q.id)).size === Q.length, "question ids are unique");
    check(Q.every(q => (q.answer === "TRUE" || q.answer === "FALSE") && q.statement && q.explanation && q.source && q.topic), "every question has statement, answer, explanation, topic, source");
    const key = a.backend.context.ANSWER_KEY;
    check(Q.every(q => key[q.id] === q.answer) && Object.keys(key).length === Q.length, "Code.gs ANSWER_KEY matches js/questions.js");
    check(a.backend.context.SETTINGS.EDITION === a.cfg.editionLabel && a.backend.context.SETTINGS.EDITION_CODE === a.cfg.editionCode, "Code.gs edition settings match config.js");
    check(a.backend.context.SETTINGS.QUESTIONS_PER_QUIZ === a.cfg.questionsPerQuiz, "Code.gs QUESTIONS_PER_QUIZ matches config.js");
    check(a.$("welcome-title").textContent === "Quiz Forum — True or False?" && /September 2026/.test(a.$("welcome-subtitle").textContent), "welcome screen shows title and September 2026");
    check(a.$("welcome-tagline").textContent === "Big brains. Quick clicks. No time to Google!", "tagline text correct");
    const src = fs.readFileSync(path.join(ROOT, "index.html"), "utf8") + fs.readFileSync(path.join(ROOT, "js", "app.js"), "utf8");
    check(!/password|private_key|client_secret/i.test(src), "no secrets in frontend source");
    a.win.close();
  }

  console.log("\n[2] Name validation");
  {
    const a = await boot();
    await a.start("");
    check(a.visible("screen-welcome") && !a.$("name-error").hidden, "empty name blocked with error");
    await a.start("     ");
    check(a.visible("screen-welcome") && !a.$("name-error").hidden, "whitespace-only name blocked");
    await a.start("பிரியா");
    check(a.visible("screen-welcome") && !a.$("name-error").hidden, "non-Latin name rejected with explanation (PDF font limit)");
    await a.start("<script>x</script>");
    check(a.visible("screen-welcome"), "HTML/script characters rejected");
    await a.start("A".repeat(61));
    check(a.visible("screen-welcome"), "61-character name rejected");
    await a.start("   Priya    Sharma   ");
    check(a.visible("screen-quiz") && a.S().name === "Priya Sharma", "extra spaces trimmed/collapsed -> 'Priya Sharma'");
    a.win.close();
  }

  console.log("\n[3] Answering, locking, double-click, keyboard, single timer");
  {
    const a = await boot();
    await a.start("Test User");
    check(a.$("progress-text").textContent === "Question 1 of 15", "progress shows 'Question 1 of 15'");
    check(a.$("timer-num").textContent === "10", "timer starts at 10");
    check(a.state.intervals === 1, "exactly one interval running");
    check(a.$("btn-true").textContent.includes("TRUE") && a.$("btn-false").textContent.includes("FALSE"), "two buttons: TRUE and FALSE");
    const q1 = a.qText();
    a.answer("TRUE"); a.answer("FALSE"); a.answer("TRUE");   // rapid clicks
    check(a.$("btn-true").disabled && a.$("btn-false").disabled, "both buttons disabled immediately after first answer");
    check(a.S().answers.q01 === "TRUE" && Object.keys(a.S().answers).length === 1, "only the first click recorded (no double scoring)");
    check(a.$("score-pill").textContent === "Score: 1", "score = 1 after correct answer");
    check(a.state.intervals === 0, "timer cleared on answer");
    check(/Big brain|Chef|Facts|Look at you/.test(a.$("reaction").textContent), "humorous reaction shown for correct answer");
    const tAns = Date.now();
    await a.nextQuestion(q1);
    const dt = Date.now() - tAns;
    check(a.$("progress-text").textContent === "Question 2 of 15", "moved to Question 2");
    check(dt >= 300 && dt <= 700, "transition took " + dt + " ms (target 300-500 ms)");
    check(a.state.intervals === 1 && a.state.maxIntervals === 1, "never more than one interval at once (max=" + a.state.maxIntervals + ")");
    check(a.$("btn-true").disabled === false, "buttons re-enabled for new question");
    const q2 = a.qText();
    a.answer("FALSE");
    check(/Oof|Close|Plot|Respectfully/.test(a.$("reaction").textContent), "reaction shown for incorrect answer");
    check(a.$("score-pill").textContent === "Score: 1", "incorrect answer adds no points");
    await a.nextQuestion(q2);
    // keyboard
    const q3 = a.qText();
    a.doc.dispatchEvent(new a.win.KeyboardEvent("keydown", { key: "t", repeat: true }));
    check(Object.keys(a.S().answers).length === 2, "held-down key (repeat) ignored");
    a.doc.dispatchEvent(new a.win.KeyboardEvent("keydown", { key: "t" }));
    a.doc.dispatchEvent(new a.win.KeyboardEvent("keydown", { key: "f" }));
    check(a.S().answers.q03 === "TRUE" && Object.keys(a.S().answers).length === 3, "keyboard T answers once; follow-up F ignored");
    a.win.close();
  }

  console.log("\n[4] Real 10-second timeout (real clock, default config)");
  {
    const a = await boot();
    check(a.cfg.timerSeconds === 10, "config timerSeconds = 10");
    await a.start("Timeout Tester");
    const q1 = a.qText(), tStart = Date.now();
    await sleep(5200);
    check(a.$("timer-num").textContent === "5" || a.$("timer-num").textContent === "4", "countdown at ~5s shows " + a.$("timer-num").textContent);
    check(a.S().answers.q01 === undefined, "question still open at 5s");
    await waitFor(() => a.S().answers.q01 === null, 8000);
    const tLock = Date.now() - tStart;
    check(a.S().answers.q01 === null, "unanswered question recorded as timeout (null) after " + tLock + " ms");
    check(tLock >= 9900 && tLock <= 10400, "timeout fired at 10.0 s (+/-0.4 s)");
    check(a.$("btn-true").disabled && a.$("btn-false").disabled, "buttons disabled on timeout");
    check(/Time's up|clock won|Blink and it/.test(a.$("reaction").textContent), "timeout reaction shown");
    check(a.$("score-pill").textContent === "Score: 0", "timeout scores zero");
    await a.nextQuestion(q1);
    check(a.$("progress-text").textContent === "Question 2 of 15" && a.$("timer-num").textContent === "10", "auto-advanced to Q2 with fresh 10 s timer");
    check(a.state.maxIntervals === 1, "single timer throughout");
    a.win.close();
  }

  console.log("\n[5] Background-tab handling (deadline based)");
  {
    const a = await boot();
    await a.start("Tab Tester");
    Object.defineProperty(a.doc, "hidden", { configurable: true, value: true });
    a.doc.dispatchEvent(new a.win.Event("visibilitychange"));
    check(!a.$("tab-warning").hidden, "tab-switch warning shown");
    a.state.perfOffset += 11000;   // pretend the browser throttled timers for 11 seconds
    Object.defineProperty(a.doc, "hidden", { configurable: true, value: false });
    a.doc.dispatchEvent(new a.win.Event("visibilitychange"));
    check(a.S().answers.q01 === null, "on return, expired deadline is converted to a timeout immediately");
    a.win.close();
  }

  console.log("\n[6] Full 15-question run with backend (timer 1 s for speed; answers: 9 right, 3 wrong, 3 timeouts)");
  let savedBackend, savedCertId;
  {
    const a = await boot();
    a.cfg.scriptUrl = "https://script.example/exec";
    a.cfg.timerSeconds = 1;
    await a.start("Priya Sharma");
    const seen = new Set();
    for (let i = 0; i < 15; i++) {
      seen.add(a.$("progress-text").textContent);
      const text = a.qText(), kind = pattern9(i);
      if (kind === "T") a.answer("TRUE"); else if (kind === "F") a.answer("FALSE"); else await sleep(1250);
      await waitFor(() => a.qText() !== text || a.visible("screen-results"), 3000);
    }
    check(seen.size === 15, "all 15 questions were displayed in order (" + seen.size + " distinct progress labels)");
    check(a.visible("screen-results") && !a.visible("screen-quiz"), "last question leads to results (no extra question)");
    check(a.state.intervals === 0, "all timers stopped at the end");
    check(a.$("result-score").textContent === "9" && a.$("result-total").textContent === "15", "results score 9 / 15");
    check(a.$("stat-correct").textContent === "9" && a.$("stat-incorrect").textContent === "3" && a.$("stat-timeout").textContent === "3", "correct 9 / incorrect 3 / timed out 3");
    check(a.$("stat-pct").textContent === "60%", "percentage 60%");
    check(a.$("result-title").textContent === "Knowledge in Progress", "band for 9 = Knowledge in Progress");
    check(a.$("review").children.length === 15, "review lists all 15 answers with explanations");
    check(/Correct answer: TRUE/.test(a.$("review").textContent) && a.$("review").querySelectorAll(".why").length === 15, "answers + explanations shown after finishing");
    await waitFor(() => a.S().save.status === "saved", 3000);
    check(a.S().save.status === "saved", "save confirmed by server");
    check(/saved by the server/.test(a.$("save-message").textContent), "UI shows 'saved' only after confirmation");
    const rows = a.backend.dataRows();
    check(rows.length === 1, "exactly one row appended");
    const r = rows[0];
    check(r[1] === "Priya Sharma" && r[2] === "September 2026" && r[3] === 9 && r[4] === 15 && r[5] === 60 && r[6] === 9 && r[7] === 3 && r[8] === 3 && /^QF-202609-[0-9A-F]{10}$/.test(r[9]) && r[10] === "Completed", "row values correct: " + JSON.stringify(r.slice(1)));
    check(r[0] instanceof Date, "timestamp stored");
    check(a.state.lastRequest.o.headers["Content-Type"].startsWith("text/plain"), "request uses text/plain (no CORS preflight)");
    check(!a.$("btn-cert").disabled, "certificate button enabled after confirmed save");
    savedBackend = a.backend; savedCertId = r[9];

    console.log("\n[7] Certificate through the UI (download path)");
    a.$("btn-cert").click();
    check(a.visible("screen-cert") && a.$("cp-name").textContent === "Priya Sharma", "certificate screen shows participant name");
    a.$("btn-download").click();
    check(a.state.blobs.length === 1 && a.state.lastDownload.name === "QuizForum_Certificate_Priya_Sharma.pdf", "download triggered: " + (a.state.lastDownload && a.state.lastDownload.name));
    const blob = a.state.blobs[0];
    const buf = await new Promise((res) => { const fr = new a.win.FileReader(); fr.onload = () => res(Buffer.from(fr.result)); fr.readAsArrayBuffer(blob); });
    const pdfPath = path.join(OUT, "certificate-priya.pdf");
    fs.writeFileSync(pdfPath, buf);
    check(buf.slice(0, 5).toString() === "%PDF-" && buf.length > 2000, "valid PDF produced (" + buf.length + " bytes)");
    const info = execFileSync("pdfinfo", [pdfPath]).toString();
    check(/Pages:\s+1/.test(info) && /84[12](\.\d+)? x 59[45](\.\d+)?/.test(info), "1 page, landscape A4 (842 x 595 pt)");
    const txt = execFileSync("pdftotext", ["-layout", pdfPath, "-"]).toString();
    for (const needle of ["QUIZ FORUM", "Certificate of Participation", "Priya Sharma", "Monthly General Knowledge & Current Affairs Quiz", "September 2026 Edition", "Score: 9 / 15", "(60%)", r[9], "Quiz Forum Coordinator", "not an accredited qualification"]) {
      check(txt.replace(/\s+/g, " ").includes(needle), "PDF text contains: " + needle);
    }
    check(/10 October 2026|\d{1,2} \w+ 2026/.test(txt), "PDF shows a completion date");
    execFileSync("pdftoppm", ["-png", "-r", "60", pdfPath, path.join(OUT, "certificate-priya")]);
    a.$("btn-print").click();
    check(typeof a.state.opened === "string", "print opens the PDF in a new window");
    a.win.close();
  }

  console.log("\n[8] Server-side validation, duplicate protection, tampering");
  {
    const b = savedBackend;
    const good = (over) => Object.assign({ action: "submit", attemptId: "attempt-aaaaaaaaaaaaaaaa", name: "Ravi Kumar", edition: "September 2026", order: b.context.ANSWER_KEY && Object.keys(b.context.ANSWER_KEY), answers: Object.keys(b.context.ANSWER_KEY).map(() => "TRUE") }, over);
    const before = b.dataRows().length;
    const r1 = b.post(good({ score: 15, percentage: 100 }));
    check(r1.ok && r1.score === 15 && b.dataRows().length === before + 1, "valid all-TRUE submission scores 15 on the server");
    const forged = b.post(good({ attemptId: "attempt-bbbbbbbbbbbbbbbb", answers: Object.keys(b.context.ANSWER_KEY).map(() => "FALSE"), score: 15 }));
    check(forged.ok && forged.score === 0, "forged score ignored: server recalculated 0 despite score:15");
    const dup = b.post(good());
    check(dup.ok && dup.duplicate === true && dup.certificateId === r1.certificateId && b.dataRows().length === before + 2, "same attemptId again -> duplicate:true, same certificate ID, no new row");
    check(b.post(good({ attemptId: "short" })).error === "invalid_attempt", "bad attempt ID rejected");
    check(b.post(good({ attemptId: "attempt-cccccccccccccccc", name: "" })).error === "invalid_name", "empty name rejected by server");
    check(b.post(good({ attemptId: "attempt-cccccccccccccccc", name: "=HYPERLINK(1)" })).error === "invalid_name", "formula-injection name rejected");
    check(b.post(good({ attemptId: "attempt-cccccccccccccccc", edition: "August 2026" })).error === "edition_mismatch", "wrong edition rejected");
    check(b.post(good({ attemptId: "attempt-cccccccccccccccc", answers: ["TRUE"] })).error === "invalid_answers", "wrong answer count rejected");
    check(b.post(good({ attemptId: "attempt-cccccccccccccccc", order: Object.keys(b.context.ANSWER_KEY).map(() => "q01") })).error === "invalid_answers", "repeated question id rejected");
    check(b.post(good({ attemptId: "attempt-cccccccccccccccc", answers: Object.keys(b.context.ANSWER_KEY).map(() => "MAYBE") })).error === "invalid_answers", "illegal answer value rejected");
    check(b.post("not json").error === "invalid_request", "garbage body rejected");
    check(b.dataRows().length === before + 2, "no rows written for any rejected request");
    check(JSON.stringify(b.get()).indexOf("TRUE") === -1 && !("rows" in b.get()), "doGet exposes no answers, names or scores");
    b.context.SETTINGS.ALLOW_MULTIPLE_ATTEMPTS_PER_NAME = false;
    check(b.post(good({ attemptId: "attempt-dddddddddddddddd", name: "ravi kumar" })).error === "already_participated", "optional one-attempt-per-name mode works");
    b.context.SETTINGS.ALLOW_MULTIPLE_ATTEMPTS_PER_NAME = true;
  }

  console.log("\n[9] Network failure, retry, lost response (no duplicate rows)");
  {
    const a = await boot();
    a.cfg.scriptUrl = "https://script.example/exec";
    a.cfg.timerSeconds = 1;
    a.state.fetchMode = "fail";
    await a.start("Meena Iyer");
    await playFullRun(a, (i) => "T");
    await waitFor(() => a.S().save.status === "failed", 3000);
    check(a.S().save.status === "failed", "network failure -> status 'failed'");
    check(!/saved by the server/.test(a.$("save-message").textContent) && /NOT been saved/.test(a.$("save-message").textContent), "UI never claims success when the save failed");
    check(!a.$("btn-retry").hidden, "retry button visible");
    check(a.$("btn-cert").disabled, "certificate blocked while unsaved (policy)");
    check(a.visible("screen-results") && a.$("result-score").textContent === "15", "results stay visible after failure");
    check(a.backend.dataRows().length === 0, "no row written on failure");
    check(!!a.win.localStorage.getItem("qf_pending_v1"), "unsaved result kept in local storage");
    const pending = a.win.localStorage.getItem("qf_pending_v1");
    a.$("btn-cert").click();
    check(!a.visible("screen-cert"), "disabled certificate button cannot open certificate");
    a.state.fetchMode = "http500"; a.$("btn-retry").click();
    await waitFor(() => a.S().save.status === "failed" && a.state.fetchCalls === 2, 2000);
    check(a.S().save.status === "failed" && /error \(500\)/.test(a.$("save-message").textContent), "HTTP 500 handled as failure");
    a.state.fetchMode = "lost-response"; a.$("btn-retry").click();   // server writes, response lost
    await waitFor(() => a.state.fetchCalls === 3 && a.S().save.status === "failed", 2000);
    check(a.backend.dataRows().length === 1 && a.S().save.status === "failed", "server wrote the row but the browser never heard back -> still shown as unsaved");
    a.state.fetchMode = "ok"; a.$("btn-retry").click();
    await waitFor(() => a.S().save.status === "saved", 2000);
    check(a.S().save.status === "saved" && a.backend.dataRows().length === 1, "retry after lost response -> saved, still exactly 1 row");
    check(a.S().save.server.duplicate === true && /already recorded/.test(a.$("save-message").textContent), "UI reports 'already recorded', no duplicate");
    check(!a.$("btn-cert").disabled && a.win.localStorage.getItem("qf_pending_v1") === null, "certificate unlocked and pending record cleared");
    a.win.close();

    console.log("\n[10] Resume an unsaved result after a page refresh");
    const b = await boot({ backend: createBackend(), localStorage: { qf_pending_v1: pending } });
    check(!b.$("pending-banner").hidden, "welcome screen offers to recover the unsaved result");
    b.cfg.scriptUrl = "https://script.example/exec";
    b.$("btn-resume").click();
    await waitFor(() => b.S() && b.S().save.status === "saved", 3000);
    check(b.visible("screen-results") && b.S().save.status === "saved" && b.backend.dataRows().length === 1 && b.backend.dataRows()[0][1] === "Meena Iyer", "recovered result saved once with the right name");
    b.win.close();
  }

  console.log("\n[11] Demo mode (no scriptUrl)");
  {
    const a = await boot();
    check(a.cfg.scriptUrl === "" && !a.$("demo-flag").hidden, "shipped config is demo mode and says so on the welcome screen");
    a.cfg.timerSeconds = 1;
    await a.start("Demo Person");
    await playFullRun(a, () => "T");
    check(a.state.fetchCalls === 0, "demo mode makes no network calls");
    check(/Demo mode/.test(a.$("save-message").textContent) && !/saved by the server/.test(a.$("save-message").textContent), "demo banner, never says 'saved'");
    check(!a.$("btn-cert").disabled, "demo certificate allowed");
    a.$("btn-cert").click(); a.$("btn-download").click();
    const buf = await new Promise((res) => { const fr = new a.win.FileReader(); fr.onload = () => res(Buffer.from(fr.result)); fr.readAsArrayBuffer(a.state.blobs[0]); });
    fs.writeFileSync(path.join(OUT, "certificate-demo.pdf"), buf);
    const txt = execFileSync("pdftotext", [path.join(OUT, "certificate-demo.pdf"), "-"]).toString();
    check(/DEMO COPY/.test(txt) && /DEMO-/.test(txt), "demo certificate is clearly stamped DEMO");
    a.win.close();
  }

  console.log("\n[12] Randomised order + swapped buttons");
  {
    const a = await boot();
    a.cfg.scriptUrl = "https://script.example/exec"; a.cfg.timerSeconds = 1; a.cfg.randomizeQuestions = true; a.cfg.randomizeButtons = true;
    await a.start("Random Rani");
    const order = a.S().order.slice();
    check(order.length === 15 && new Set(order).size === 15, "15 unique questions in randomised order");
    check(order.join() !== a.win.QF_QUESTIONS.map(q => q.id).join(), "order differs from the default (random; vanishingly unlikely to match)");
    await playFullRun(a, () => "T");
    await waitFor(() => a.S().save.status === "saved", 3000);
    check(a.S().save.status === "saved" && a.backend.dataRows()[0][3] === 15, "server scores a shuffled attempt correctly (15)");
    a.win.close();
  }

  console.log("\n[13] Long names on the certificate");
  {
    const a = await boot();
    const longName = "Alexandria Bartholomew Montgomery-Featherstonehaugh Jr";
    for (const nm of [longName, "Li", "Jean-Luc O'Brien-Díaz"]) {
      const doc = a.win.QFCertificate.build({ name: nm, score: 15, total: 15, percentage: 100, completedAt: new Date(), certId: "QF-202609-ABCDEF1234", edition: "September 2026", quizName: "Monthly General Knowledge & Current Affairs Quiz", organizer: "Quiz Forum", certificateTitle: "Certificate of Participation", coordinatorTitle: "Quiz Forum Coordinator" });
      const p = path.join(OUT, "cert-" + nm.slice(0, 6).replace(/\W/g, "") + ".pdf");
      fs.writeFileSync(p, Buffer.from(doc.output("arraybuffer")));
      const txt = execFileSync("pdftotext", [p, "-"]).toString().replace(/\s+/g, " ");
      check(txt.includes(nm), "name rendered as one text line in PDF: " + nm + " (" + nm.length + " chars)");
      const bbox = execFileSync("pdftotext", ["-bbox", p, "-"]).toString();
      const words = nm.split(" ");
      const first = new RegExp('xMin="([\\d.]+)"[^>]*xMax="([\\d.]+)"[^>]*>' + words[0].replace(/[-'.í]/g, ".") + "<").exec(bbox);
      const lastW = words[words.length - 1].replace(/[-'.í]/g, ".");
      const last = new RegExp('xMin="([\\d.]+)"[^>]*xMax="([\\d.]+)"[^>]*>' + lastW + "<").exec(bbox);
      if (first && last) {
        const left = parseFloat(first[1]), right = parseFloat(last[2]);
        check(left > 40 && right < 842 - 40, "name fits inside the border (x " + left.toFixed(0) + " to " + right.toFixed(0) + " of 842)");
      }
      if (nm === longName) execFileSync("pdftoppm", ["-png", "-r", "60", p, path.join(OUT, "cert-long")]);
    }
    a.win.close();
  }

  console.log("\n[14] Page errors");
  {
    const a = await boot(); await a.start("Err Check");
    check(a.state.errors.length === 0, "no uncaught JS errors in the page" + (a.state.errors.length ? ": " + a.state.errors.join("; ") : ""));
    a.win.close();
  }

  console.log("\n==============================");
  console.log("Passed: " + passed + "   Failed: " + failed + "   (" + ((Date.now() - t0) / 1000).toFixed(1) + " s)");
  if (failed) { console.log("Failures:\n - " + failures.join("\n - ")); process.exit(1); }
  process.exit(0);
})().catch((e) => { console.error("TEST HARNESS CRASH:", e); process.exit(2); });
