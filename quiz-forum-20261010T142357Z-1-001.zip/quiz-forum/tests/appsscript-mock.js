/* Runs apps-script/Code.gs in Node with an in-memory fake of SpreadsheetApp/LockService/etc.
   This tests the server LOGIC. It does not talk to Google. */
"use strict";
const fs = require("fs");
const path = require("path");
const vm = require("vm");
const crypto = require("crypto");

function createBackend() {
  const rows = [];                       // rows[0] = header row once created
  let sheetExists = false;
  const log = { locks: 0 };

  const sheet = {
    getName: () => "Participants",
    getLastRow: () => rows.length,
    getRange(r, c, nr, nc) {
      return {
        getValues: () => rows.slice(r - 1, r - 1 + (nr || 1)).map(row => row.slice(c - 1, c - 1 + (nc || 1))),
        setValues(v) { rows[r - 1] = v[0].slice(); return this; },
        setFontWeight() { return this; }
      };
    },
    appendRow: (row) => { rows.push(row.slice()); },
    setFrozenRows() {}
  };
  const ss = {
    getSheetByName: (n) => (sheetExists && n === "Participants" ? sheet : null),
    insertSheet: () => { sheetExists = true; return sheet; }
  };

  const context = {
    SpreadsheetApp: { getActiveSpreadsheet: () => ss },
    LockService: { getScriptLock: () => ({ tryLock: () => { log.locks++; return true; }, releaseLock() {} }) },
    ContentService: {
      MimeType: { JSON: "json" },
      createTextOutput: (text) => ({ text, setMimeType() { return this; }, getContent() { return this.text; } })
    },
    Utilities: {
      DigestAlgorithm: { SHA_256: "sha256" },
      computeDigest: (alg, str) => Array.from(crypto.createHash("sha256").update(str, "utf8").digest()).map(b => (b > 127 ? b - 256 : b))
    },
    Logger: { log() {} },
    JSON, Date, Math, Array, String, Number, Object, RegExp
  };
  vm.createContext(context);
  vm.runInContext(fs.readFileSync(path.join(__dirname, "..", "apps-script", "Code.gs"), "utf8"), context, { filename: "Code.gs" });

  return {
    context, rows, log,
    post(bodyObj) {
      const out = context.doPost({ postData: { contents: typeof bodyObj === "string" ? bodyObj : JSON.stringify(bodyObj) } });
      return JSON.parse(out.getContent());
    },
    get() { return JSON.parse(context.doGet().getContent()); },
    dataRows() { return rows.slice(1); }
  };
}

module.exports = { createBackend };
