/**
 * QUIZ FORUM — Google Apps Script backend (bound to your Google Sheet)
 *
 * What it does
 *  - doPost: receives a FINISHED attempt, re-scores it from the answer key below
 *            (the score sent by the browser is never trusted), and appends one row.
 *  - doGet : health check only. It never returns names, scores or the answer key.
 *
 * Duplicate protection
 *  - The certificate ID is derived from the attempt ID (SHA-256). If that ID is already
 *    in the sheet, the existing record is returned and NO new row is written.
 *  - A script lock serialises simultaneous submissions.
 *
 * Setup: see README.md section 5-6. Run setup() once to authorise and create the sheet.
 */

/* ========== SETTINGS (must match js/config.js) ========== */
var SETTINGS = {
  SHEET_NAME: 'Participants',
  EDITION: 'September 2026',      // = editionLabel in js/config.js
  EDITION_CODE: '202609',         // = editionCode  in js/config.js
  QUESTIONS_PER_QUIZ: 15,         // = questionsPerQuiz
  POINTS_PER_CORRECT: 1,          // = pointsPerCorrect
  ALLOW_MULTIPLE_ATTEMPTS_PER_NAME: true  // false = one record per name per edition
};

/* ========== ANSWER KEY ==========
 * Generate this block with admin-key.html (opens in your browser) and paste it here.
 * Keep ids identical to js/questions.js.
 */
var ANSWER_KEY = {
  q01: 'TRUE', q02: 'TRUE', q03: 'TRUE', q04: 'TRUE', q05: 'TRUE',
  q06: 'TRUE', q07: 'TRUE', q08: 'TRUE', q09: 'TRUE', q10: 'TRUE',
  q11: 'TRUE', q12: 'TRUE', q13: 'TRUE', q14: 'TRUE', q15: 'TRUE'
};

var HEADERS = [
  'Timestamp', 'Participant Name', 'Quiz Edition', 'Score', 'Total Questions', 'Percentage',
  'Correct Answers', 'Incorrect Answers', 'Timed-out Questions', 'Certificate ID', 'Completion Status'
];
var COL = { TIMESTAMP: 1, NAME: 2, EDITION: 3, SCORE: 4, TOTAL: 5, PCT: 6, CORRECT: 7, WRONG: 8, TIMEOUT: 9, CERT: 10, STATUS: 11 };

var NAME_RE = /^[A-Za-zÀ-ÖØ-öø-ÿ][A-Za-zÀ-ÖØ-öø-ÿ .'’\-]*$/;
var ATTEMPT_RE = /^[A-Za-z0-9\-]{16,64}$/;

/* ---------- Run ONCE from the editor: authorises the script and creates the sheet ---------- */
function setup() {
  var sheet = getSheet_();
  Logger.log('Ready. Sheet "' + sheet.getName() + '" has ' + Math.max(sheet.getLastRow() - 1, 0) + ' record(s).');
}

/* ---------- Web app entry points ---------- */
function doGet() {
  return json_({ ok: true, service: 'Quiz Forum', edition: SETTINGS.EDITION, questions: SETTINGS.QUESTIONS_PER_QUIZ });
}

function doPost(e) {
  var lock = LockService.getScriptLock();
  try {
    if (!lock.tryLock(20000)) return json_({ ok: false, error: 'busy' });
    var body;
    try { body = JSON.parse(e && e.postData && e.postData.contents || ''); }
    catch (err) { return json_({ ok: false, error: 'invalid_request' }); }
    if (!body || body.action !== 'submit') return json_({ ok: false, error: 'invalid_request' });
    return json_(handleSubmit_(body));
  } catch (err) {
    return json_({ ok: false, error: 'server_error' });
  } finally {
    try { lock.releaseLock(); } catch (ignore) {}
  }
}

/* ---------- Core logic ---------- */
function handleSubmit_(body) {
  // 1. validate fields
  var attemptId = String(body.attemptId || '');
  if (!ATTEMPT_RE.test(attemptId)) return { ok: false, error: 'invalid_attempt' };

  var name = String(body.name || '').replace(/’/g, "'").replace(/\s+/g, ' ').trim();
  if (name.length < 2 || name.length > 80 || !NAME_RE.test(name)) return { ok: false, error: 'invalid_name' };

  if (String(body.edition || '') !== SETTINGS.EDITION) return { ok: false, error: 'edition_mismatch' };

  var order = body.order, answers = body.answers;
  if (!Array.isArray(order) || !Array.isArray(answers) ||
      order.length !== SETTINGS.QUESTIONS_PER_QUIZ || answers.length !== order.length) {
    return { ok: false, error: 'invalid_answers' };
  }
  var seen = {};
  for (var i = 0; i < order.length; i++) {
    var qid = String(order[i]);
    if (!ANSWER_KEY.hasOwnProperty(qid) || seen[qid]) return { ok: false, error: 'invalid_answers' };
    seen[qid] = true;
    var a = answers[i];
    if (a !== null && a !== 'TRUE' && a !== 'FALSE') return { ok: false, error: 'invalid_answers' };
  }

  // 2. score on the server from the trusted key
  var correct = 0, wrong = 0, timedOut = 0;
  for (var j = 0; j < order.length; j++) {
    var given = answers[j];
    if (given === null) timedOut++;
    else if (given === ANSWER_KEY[String(order[j])]) correct++;
    else wrong++;
  }
  var maxScore = SETTINGS.QUESTIONS_PER_QUIZ * SETTINGS.POINTS_PER_CORRECT;
  var score = correct * SETTINGS.POINTS_PER_CORRECT;
  var percentage = Math.round(score / maxScore * 1000) / 10;

  // 3. duplicate protection
  var certId = makeCertId_(attemptId);
  var sheet = getSheet_();
  var existing = findRow_(sheet, certId);
  if (existing) return existingResponse_(sheet, existing, true);

  if (!SETTINGS.ALLOW_MULTIPLE_ATTEMPTS_PER_NAME && nameExists_(sheet, name)) {
    return { ok: false, error: 'already_participated' };
  }

  // 4. write (neutralise spreadsheet formulas in the name)
  var safeName = /^[=+\-@]/.test(name) ? "'" + name : name;
  var now = new Date();
  sheet.appendRow([now, safeName, SETTINGS.EDITION, score, SETTINGS.QUESTIONS_PER_QUIZ, percentage,
                   correct, wrong, timedOut, certId, 'Completed']);

  return {
    ok: true, duplicate: false, certificateId: certId, name: name,
    score: score, maxScore: maxScore, total: SETTINGS.QUESTIONS_PER_QUIZ, percentage: percentage,
    correct: correct, incorrect: wrong, timedOut: timedOut, completedAt: now.toISOString()
  };
}

function existingResponse_(sheet, row, isDuplicate) {
  var v = sheet.getRange(row, 1, 1, HEADERS.length).getValues()[0];
  var ts = v[COL.TIMESTAMP - 1];
  var name = String(v[COL.NAME - 1]).replace(/^'/, '');
  return {
    ok: true, duplicate: !!isDuplicate, certificateId: String(v[COL.CERT - 1]), name: name,
    score: Number(v[COL.SCORE - 1]), maxScore: Number(v[COL.TOTAL - 1]) * SETTINGS.POINTS_PER_CORRECT,
    total: Number(v[COL.TOTAL - 1]), percentage: Number(v[COL.PCT - 1]),
    correct: Number(v[COL.CORRECT - 1]), incorrect: Number(v[COL.WRONG - 1]), timedOut: Number(v[COL.TIMEOUT - 1]),
    completedAt: (ts instanceof Date) ? ts.toISOString() : new Date(ts).toISOString()
  };
}

/* ---------- Helpers ---------- */
function getSheet_() {
  var ss = SpreadsheetApp.getActiveSpreadsheet();
  var sheet = ss.getSheetByName(SETTINGS.SHEET_NAME);
  if (!sheet) sheet = ss.insertSheet(SETTINGS.SHEET_NAME);
  if (sheet.getLastRow() === 0) {
    sheet.getRange(1, 1, 1, HEADERS.length).setValues([HEADERS]).setFontWeight('bold');
    sheet.setFrozenRows(1);
  }
  return sheet;
}

function makeCertId_(attemptId) {
  var bytes = Utilities.computeDigest(Utilities.DigestAlgorithm.SHA_256, attemptId);
  var hex = bytes.map(function (b) { return ('0' + ((b < 0 ? b + 256 : b)).toString(16)).slice(-2); }).join('');
  return 'QF-' + SETTINGS.EDITION_CODE + '-' + hex.slice(0, 10).toUpperCase();
}

function findRow_(sheet, certId) {
  var last = sheet.getLastRow();
  if (last < 2) return 0;
  var ids = sheet.getRange(2, COL.CERT, last - 1, 1).getValues();
  for (var i = 0; i < ids.length; i++) if (String(ids[i][0]) === certId) return i + 2;
  return 0;
}

function nameExists_(sheet, name) {
  var last = sheet.getLastRow();
  if (last < 2) return false;
  var rows = sheet.getRange(2, 1, last - 1, HEADERS.length).getValues();
  var target = name.toLowerCase();
  for (var i = 0; i < rows.length; i++) {
    if (String(rows[i][COL.NAME - 1]).replace(/^'/, '').toLowerCase() === target &&
        String(rows[i][COL.EDITION - 1]) === SETTINGS.EDITION) return true;
  }
  return false;
}

function json_(obj) {
  return ContentService.createTextOutput(JSON.stringify(obj)).setMimeType(ContentService.MimeType.JSON);
}
